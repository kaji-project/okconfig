
export PATH=$PATH:/usr/lib64/nagios/plugins:/usr/lib/nagios/plugins
